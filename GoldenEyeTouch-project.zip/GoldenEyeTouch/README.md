# GoldenEye Touch — Android project

**Important honesty note:** this archive is a buildable *UI scaffold*, not yet a playable emulator frontend. It includes a ROM document picker, persisted URI permission, a custom-drawn GoldenEye-inspired touch deck, Android project configuration, and a GitHub Actions workflow that downloads the N64 core binaries. It does **not** yet instantiate LibretroDroid or send the drawn controls to the emulator. Do not mistake selecting a ROM for launching the game. I cannot honestly promise gameplay from this build.

## Legal/content
- No game ROM, BIOS, copyrighted game art, or Nintendo logo is included.
- Select only a ROM you are legally entitled to use.
- GoldenEye 007 is a Nintendo 64 game. Mupen64Plus-Next is the chosen Libretro core.
- N64 emulation normally does not require a console BIOS for standard cartridge games.

## Phone-only GitHub steps
1. Download and extract `GoldenEyeTouch-project.zip`.
2. In GitHub mobile browser, create an empty repository.
3. Upload the **contents** of the extracted folder, including `.github/workflows/build.yml` (GitHub's upload interface may hide dot-folders; if so create `.github/workflows` in the web editor and add `build.yml`).
4. Open **Actions**, allow workflows if prompted, and run **Android debug build** or push a commit.
5. Open the completed run and download the `goldeneye-touch-debug-apk` artifact. Extract the downloaded artifact ZIP and install the APK, allowing installs from that browser/files app if Android asks.

## What the workflow does
- Uses JDK 17 and Android SDK platform 34.
- Downloads Mupen64Plus-Next GLES3 for `arm64-v8a` and GLES2 for `armeabi-v7a` from Libretro's Android buildbot, then unpacks them into `app/src/main/jniLibs`.
- Runs `gradle assembleDebug` and uploads `app/build/outputs/apk/debug/app-debug.apk`.

## Known limitations
- **Gameplay/runtime:** not connected yet; LibretroDroid API integration and testing are required before the ROM can run. This is the key blocker, not a setting you can fix in GitHub.
- **Save states/SRAM, rewind, fast-forward, cheats, shader pipeline, core options, physical gamepad mapping:** not implemented in this scaffold.
- **Widescreen:** only expose once the real Mupen64Plus-Next core option is wired and tested; it can cause game-specific glitches.
- **Resolution/AA:** N64 core/plugin settings may offer internal upscaling; display scaling is not internal resolution. Do not claim MSAA/FXAA unless the chosen renderer actually supports it.
- **First build:** GitHub must be able to reach Google Maven, Maven Central, and Libretro buildbot. If the buildbot changes ZIP layout or filenames, the core-download step will fail; see workflow log for the exact URL/error.

## Research links
- LibretroDroid project and supported features: https://github.com/Swordfish90/LibretroDroid
- Mupen64Plus-Next docs and options: https://docs.libretro.com/library/mupen64plus/
- Android arm64 core directory: https://buildbot.libretro.com/nightly/android/latest/arm64-v8a/
- Android armeabi-v7a core directory: https://buildbot.libretro.com/nightly/android/latest/armeabi-v7a/
