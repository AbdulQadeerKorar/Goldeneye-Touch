package com.agent007.touch

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.MotionEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.Toast

class MainActivity : Activity() {
    private var romUri: Uri? = null
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("goldeneye", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(8,11,14)); setPadding(18,18,18,18) }
        val title = TextView(this).apply { text = "G O L D E N E Y   /   0 0 7"; textSize = 23f; setTextColor(Color.rgb(230,184,74)); typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD); gravity = android.view.Gravity.CENTER; setPadding(4,16,4,8) }
        root.addView(title, LinearLayout.LayoutParams(-1, 62))
        val subtitle = TextView(this).apply { text = "N64 FIELD TERMINAL  •  TOUCH DECK"; textSize = 11f; setTextColor(Color.LTGRAY); gravity = android.view.Gravity.CENTER; letterSpacing = .18f }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 28))
        val screen = View(this).apply { background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(19,25,29)); setStroke(2, Color.rgb(115,91,43)); cornerRadius = 12f } }
        root.addView(screen, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0,10,0,12) })
        status = TextView(this).apply { text = "NO GAME FILE SELECTED\nChoose your own legally obtained N64 ROM (.z64 / .n64 / .v64)."; textSize = 13f; setTextColor(Color.rgb(232,220,185)); gravity = android.view.Gravity.CENTER; setPadding(8,8,8,8) }
        root.addView(status, LinearLayout.LayoutParams(-1, 66))
        val pick = goldButton("SELECT YOUR ROM") { openRomPicker() }
        root.addView(pick, LinearLayout.LayoutParams(-1, 52).apply { setMargins(0,8,0,8) })
        val controls = ControlDeck(this)
        root.addView(controls, LinearLayout.LayoutParams(-1, 205))
        val note = TextView(this).apply { text = "ENGINE STATUS: CORE FILES ARE DOWNLOADED BY GITHUB ACTIONS.\nThe LibretroDroid runtime adapter is not yet wired into this UI build."; textSize = 10f; setTextColor(Color.rgb(209,163,70)); gravity = android.view.Gravity.CENTER; setPadding(4,8,4,0) }
        root.addView(note, LinearLayout.LayoutParams(-1, 48))
        setContentView(root)
        prefs.getString("rom_uri", null)?.let { status.text = "REMEMBERED ROM URI\n$it\nTap SELECT YOUR ROM to re-authorize if needed." }
    }

    private fun goldButton(label: String, action: () -> Unit) = Button(this).apply { text = label; textSize = 13f; letterSpacing = .1f; setTextColor(Color.rgb(8,11,14)); setBackgroundColor(Color.rgb(230,184,74)); setOnClickListener { action() } }

    private fun openRomPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-n64-rom")) }
        startActivityForResult(intent, 701)
    }

    @Deprecated("Deprecated by Android; retained for API 24 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 701 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try { contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            romUri = uri
            prefs.edit().putString("rom_uri", uri.toString()).apply()
            status.text = "ROM SELECTED\n${uri.lastPathSegment ?: uri.toString()}\nFile access remembered. Emulator launch is not connected in this build."
            Toast.makeText(this, "ROM access saved", Toast.LENGTH_SHORT).show()
        }
    }
}

private class ControlDeck(context: android.content.Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pressed = mutableSetOf<Int>()
    private val labels = listOf("◈", "✦", "⬡", "❖", "⌁", "⟐", "◉", "⌖", "⤢", "⤡")
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(Color.rgb(8,11,14))
        val gold = Color.rgb(230,184,74); val muted = Color.rgb(61,72,75)
        val w = width.toFloat(); val h = height.toFloat()
        // left D-pad
        val cx = w*.20f; val cy = h*.50f; val r = h*.27f
        p.style=Paint.Style.STROKE; p.strokeWidth=2f; p.color=gold; c.drawCircle(cx,cy,r*1.35f,p)
        p.style=Paint.Style.FILL; p.color=muted
        c.drawRoundRect(cx-r*.35f,cy-r,cx+r*.35f,cy+r,8f,8f,p); c.drawRoundRect(cx-r,cy-r*.35f,cx+r,cy+r*.35f,8f,8f,p)
        p.color=gold; c.drawCircle(cx,cy,r*.22f,p)
        // right face glyphs
        val bx=w*.77f; val by=h*.50f; val br=h*.14f
        for (i in 0..3) {
            val a = Math.toRadians((i*90-45).toDouble()); val x=bx+ kotlin.math.cos(a).toFloat()*br*1.9f; val y=by+kotlin.math.sin(a).toFloat()*br*1.9f
            p.color=if(pressed.contains(i)) Color.rgb(255,224,132) else muted; p.style=Paint.Style.FILL; c.drawCircle(x,y,br,p)
            p.color=gold; p.style=Paint.Style.STROKE; p.strokeWidth=2f; c.drawCircle(x,y,br,p)
            p.style=Paint.Style.FILL; p.textAlign=Paint.Align.CENTER; p.textSize=br*.9f; c.drawText(labels[i],x,y+br*.32f,p)
        }
        // shoulders / menu glyphs
        p.color=gold; p.style=Paint.Style.STROKE; p.strokeWidth=2f
        c.drawRoundRect(w*.06f,h*.04f,w*.34f,h*.22f,12f,12f,p); c.drawRoundRect(w*.66f,h*.04f,w*.94f,h*.22f,12f,12f,p)
        p.style=Paint.Style.FILL; p.textSize=13f; p.textAlign=Paint.Align.CENTER; c.drawText("❮  L",w*.20f,h*.155f,p); c.drawText("R  ❯",w*.80f,h*.155f,p)
        c.drawRoundRect(w*.42f,h*.76f,w*.58f,h*.95f,10f,10f,p); p.textSize=12f; c.drawText("◇",w*.50f,h*.885f,p)
        p.textSize=9f; p.color=Color.rgb(125,130,124); c.drawText("TACTILE DECK • N64 BUTTON MAP CONCEPT",w*.50f,h*.68f,p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean { when(e.actionMasked){ MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { pressed.add(e.actionIndex); performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); invalidate() }; MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> { pressed.clear(); invalidate() } }; return true }
}
