# GoldenEye: Field Kit — Android frontend project

**Important status:** this ZIP is a UI/build scaffold, not a complete playable emulator app yet. The ROM picker, persistent URI permission, themed UI mockup, skin selector, settings information screen, Gradle project and GitHub Actions workflow are present. The LibretroDroid runtime session is **not wired to the UI** and the drawn touch controls are decorative, not N64 input. Do not expect GoldenEye to boot from this build. This is stated explicitly rather than pretending the emulator works.

## Target and legal content
- Game/platform: GoldenEye 007, Nintendo 64.
- Intended core: Mupen64Plus-Next GLES3 Android core. Upstream documents Android GLES2/GLES3 variants, N64 ROM extensions, core options including aspect ratio, internal rendering resolution and MSAA (availability depends on platform), and save states/SRAM support in RetroArch. LibretroDroid lists Mupen64Plus among tested cores and supports state/SRAM serialization, shaders, touchscreen and core variables.
- Standard N64 games generally do not require a BIOS. The core may create/use its own `Mupen64plus/` system directory for `mupen64plus.ini` and shaders; the app currently does not expose a system-folder picker.
- No game ROM, BIOS, copyrighted artwork or commercial game data is included. Use only your own lawful dump or homebrew/freeware.

## Phone-only GitHub workflow
1. Download and unzip this project on your phone.
2. In GitHub, create a new empty repository.
3. Upload the extracted project files and folders (not the ZIP itself) using GitHub's web upload. Ensure `.github/workflows/build.yml` is included. If the mobile uploader hides dot-folders, create the workflow file in GitHub's web editor at `.github/workflows/build.yml` and paste the root `build.yml` contents.
4. Open **Actions** → **Android debug APK** → latest run. If Actions are disabled, enable them in the repository.
5. When the run succeeds, download the `goldeneye-touch-debug-apk` artifact, unzip it, and install `app-debug.apk`. Android may ask you to allow installation from that browser/files app.

## Build configuration
- Android Gradle Plugin 8.5.2, Kotlin 1.9.24, Gradle 8.9, JDK 17, minSdk 24, compileSdk 34.
- The workflow fetches Mupen64Plus-Next GLES3 `.so` archives for arm64-v8a and armeabi-v7a at build time, and packages native libraries with legacy packaging.

## Known limitations / first-build risks
1. **Not playable yet:** the LibretroDroid session lifecycle, GL surface, ROM streaming/path handling, core environment, input mapping, SRAM autosave and state serialization still need implementation against a pinned, verified LibretroDroid API. The current app deliberately reports this. A successful APK build would not prove gameplay.
2. **Dependency/JitPack:** `com.github.swordfish90:libretrodroid:0.9.0` may not be a published tag. If Gradle says it cannot resolve the artifact, inspect the real tags at https://github.com/Swordfish90/LibretroDroid/releases and replace the version with a published tag; do not guess a version.
3. **Core archive contents/URL:** the workflow lists archive contents and fails if no `.so` is extracted. If the buildbot changes the path or archive layout, check https://buildbot.libretro.com/nightly/android/latest/arm64-v8a/ and the matching `armeabi-v7a/` listing; update the two URLs or the extraction glob.
4. **Feature claims:** settings are explanatory UI only. CRT/LCD shader toggles, pixel scaling, audio, FPS, fast-forward, rewind, save slots, cheats, physical gamepad mapping, layout editing, and actual haptics are not connected to a running core. Cheats require a verified LibretroDroid API for `retro_cheat_set` or a small JNI addition.
5. **N64 widescreen/resolution/AA:** Mupen64Plus-Next documents aspect ratio 4:3 / 16:9 / 16:9 adjusted, resolution options and MSAA on supported builds. Widescreen can distort or glitch game content. 2D-style display scaling is not relevant here; N64 internal resolution is core/renderer-dependent. TAA is not a normal retro-core feature.
6. **ROM loading:** the selected URI is remembered, but the file is not yet passed to the core. Large-file path/stream integration is not implemented.

## Research references
- LibretroDroid supported capabilities and tested cores: https://github.com/Swordfish90/LibretroDroid
- Mupen64Plus-Next Android variants, features, directories and options: https://docs.libretro.com/library/mupen64plus/
- Android core buildbot listing: https://buildbot.libretro.com/nightly/android/latest/arm64-v8a/
