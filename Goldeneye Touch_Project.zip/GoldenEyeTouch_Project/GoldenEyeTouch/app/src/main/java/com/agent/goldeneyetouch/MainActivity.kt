package com.agent.goldeneyetouch

import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** UI prototype for a GoldenEye-inspired N64 frontend. Game-engine bridge is intentionally not faked. */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("fieldkit", MODE_PRIVATE) }
    private val pickGame = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(8, 14, 14)); setPadding(20, 20, 20, 14) }
        val header = TextView(this).apply { text = "FIELD KIT     /     N64\nGOLDEN HOUR • AGENT INTERFACE"; setTextColor(Color.rgb(214,181,109)); textSize = 17f; letterSpacing = .12f; gravity = Gravity.CENTER_VERTICAL; setPadding(4, 4, 4, 14) }
        root.addView(header)
        status = TextView(this).apply { text = prefs.getString("game_uri", null)?.let { "GAME FILE REMEMBERED\nChoose Play after the emulator bridge is integrated." } ?: "NO GAME FILE SELECTED\nChoose your own legal N64 dump (.z64 / .n64 / .v64)."; setTextColor(Color.LTGRAY); textSize = 13f; setPadding(12, 16, 12, 16) }
        root.addView(status)
        val screen = View(this).apply { background = null; setLayerType(View.LAYER_TYPE_SOFTWARE, null) }
        screen.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        screen.setBackgroundColor(Color.rgb(3, 7, 7))
        root.addView(screen)
        val controls = AgentControls(this)
        root.addView(controls, LinearLayout.LayoutParams(-1, 250))
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row1.addView(actionButton("LOAD GAME") { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-n64-rom")); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }; startActivityForResult(i, pickGame) }, weight())
        row1.addView(actionButton("SLOTS / SAVE") { Toast.makeText(this@MainActivity, "Save states require the LibretroDroid runtime session bridge; not wired in this prototype.", Toast.LENGTH_LONG).show() }, weight())
        root.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row2.addView(actionButton("THEMES") { showThemes() }, weight())
        row2.addView(actionButton("SETTINGS") { showSettings() }, weight())
        root.addView(row2)
        setContentView(root)
    }

    private fun weight() = LinearLayout.LayoutParams(0, 54, 1f).apply { setMargins(4, 5, 4, 0) }
    private fun actionButton(label: String, click: () -> Unit) = Button(this).apply { text = label; setTextColor(Color.rgb(214,181,109)); setBackgroundColor(Color.rgb(24,32,30)); textSize = 11f; setOnClickListener { click() } }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickGame && resultCode == Activity.RESULT_OK) data?.data?.let { uri: Uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            prefs.edit().putString("game_uri", uri.toString()).apply()
            status.text = "GAME FILE SELECTED\n$uri\n\nNote: file selection is implemented; game execution awaits a verified LibretroDroid session adapter."
        }
    }

    private fun showThemes() {
        val themes = arrayOf("FIELD GOLD", "BONE ON INK", "GOTHIC CRIMSON", "NEON SYNTHWAVE", "ARCHIVE PARCHMENT", "FROSTED GLASS")
        android.app.AlertDialog.Builder(this).setTitle("SELECT SKIN").setItems(themes) { _, which -> prefs.edit().putInt("skin", which).apply(); Toast.makeText(this, "Skin saved: ${themes[which]}. Full per-control styling is planned, not yet wired.", Toast.LENGTH_SHORT).show() }.show()
    }
    private fun showSettings() {
        android.app.AlertDialog.Builder(this).setTitle("FIELD SETTINGS").setMessage("Verified target core: Mupen64Plus-Next GLES3.\n\nCore options documented upstream include 4:3 / 16:9 aspect, internal resolution, bilinear mode and MSAA (renderer/platform dependent). These options are not yet connected to a running core in this prototype.\n\nNo BIOS is normally required for standard N64 ROMs.").setPositiveButton("OK", null).show()
    }
}

private class AgentControls(context: android.content.Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val active = mutableSetOf<Int>()
    private val names = listOf("MOVE", "A", "B", "C↑", "C←", "C→", "C↓", "L", "R", "START")
    override fun onDraw(c: Canvas) {
        super.onDraw(c); c.drawColor(Color.rgb(8, 14, 14))
        val gold = Color.rgb(214,181,109); val muted = Color.rgb(61,79,73)
        val centers = listOf(.15f to .52f, .72f to .65f, .86f to .53f, .86f to .26f, .75f to .26f, .95f to .26f, .86f to .39f, .22f to .12f, .78f to .12f, .50f to .12f)
        centers.forEachIndexed { i, pair ->
            val x = width * pair.first; val y = height * pair.second; val r = if (i == 0) width * .105f else width * .045f
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = if (i in active) gold else muted
            c.drawCircle(x, y, r, p)
            if (i == 0) { c.drawCircle(x, y, r * .58f, p); c.drawLine(x-r*.8f,y,x+r*.8f,y,p); c.drawLine(x,y-r*.8f,x,y+r*.8f,p) }
            else { p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = r*.58f; p.color = if (i in active) Color.WHITE else gold; c.drawText(listOf("", "◆", "◇", "⌃", "‹", "›", "⌄", "◈", "◉", "✦")[i], x, y+r*.2f, p) }
        }
        p.style = Paint.Style.FILL; p.textSize = 22f; p.textAlign = Paint.Align.CENTER; p.color = gold; c.drawText("FIELD CONTROLS", width/2f, height*.78f, p)
        p.textSize = 10f; p.color = Color.GRAY; c.drawText("DECORATIVE TOUCH MOCKUP • INPUT NOT CONNECTED", width/2f, height*.85f, p)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_MOVE -> { active.clear(); for (i in 0 until event.pointerCount) { val x = event.getX(i)/width; val y = event.getY(i)/height; if (x < .35f) active.add(0) else if (x > .65f) active.add(if (y > .45f) 1 else 3) else active.add(9) }; performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP); invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_UP -> { active.clear(); invalidate() }
        }; return true
    }
}
