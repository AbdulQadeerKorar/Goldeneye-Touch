# GoldenEye N64 – stylized touch player (Mupen64Plus-Next via LibretroDroid)
1. New GitHub repo. Upload GoldenEyeN64.zip (not unzipped) to the root.
2. Create `.github/workflows/build.yml` with the workflow text, commit.
3. Actions -> Build GoldenEye N64 APK -> download artifact GoldenEyeN64-apk, install (arm64 phones only).
4. Open the app, pick your own game file (.z64/.n64/.v64).
Menu: save/load state, settings (widescreen, resolution, MSAA, FXAA, texture filter, presets, pad opacity, haptics,
button mapping fix, fast-forward, mute), cheats (GameShark), restart, change game.
