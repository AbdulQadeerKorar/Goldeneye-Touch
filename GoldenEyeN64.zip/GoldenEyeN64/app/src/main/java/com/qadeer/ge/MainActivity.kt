package com.qadeer.ge

import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private const val ASPECT_KEY = "mupen64plus-aspect"

private class Opt(val label: String, val key: String, val names: List<String>, val values: List<String>, val def: Int)

private val OPTS = listOf(
    Opt("Widescreen", ASPECT_KEY, listOf("Off (4:3)", "16:9 stretch", "16:9 adjusted (hack)"), listOf("4:3", "16:9", "16:9 adjusted"), 0),
    Opt("Resolution (4:3)", "mupen64plus-43screensize",
        listOf("320x240 (native)", "640x480", "960x720", "1280x960", "1440x1080"),
        listOf("320x240", "640x480", "960x720", "1280x960", "1440x1080"), 1),
    Opt("Resolution (16:9)", "mupen64plus-169screensize",
        listOf("640x360", "960x540", "1280x720", "1920x1080"),
        listOf("640x360", "960x540", "1280x720", "1920x1080"), 0),
    Opt("Anti-aliasing (MSAA)", "mupen64plus-MultiSampling", listOf("Off", "2x", "4x", "8x"), listOf("0", "2", "4", "8"), 0),
    Opt("FXAA", "mupen64plus-FXAA", listOf("Off", "On"), listOf("0", "1"), 0),
    Opt("Texture filter", "mupen64plus-BilinearMode", listOf("3-point (N64 style)", "Standard bilinear"), listOf("3point", "standard"), 0)
)

private class Cheat(var name: String, var code: String, var on: Boolean)

class MainActivity : ComponentActivity(), N64Pad.Listener {

    private lateinit var root: FrameLayout
    private lateinit var pad: N64Pad
    private lateinit var splash: TextView
    private lateinit var prefs: SharedPreferences
    private var retro: GLRetroView? = null
    private var romKey = ""
    private var fastForward = 1
    private var muted = false
    private val handler = Handler(Looper.getMainLooper())
    private val autosave = object : Runnable {
        override fun run() { saveSram(); handler.postDelayed(this, 30_000) }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val changing = retro != null
            if (changing) saveSram()
            prefs.edit().putString("rom", uri.toString()).apply()
            if (changing) recreate() else startGame(uri)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val gold = Color.parseColor("#D9B54A")

    // ----------------------------------------------------------- reflection helpers
    private fun callMethod(target: Any, name: String, vararg args: Any?): Boolean = try {
        val m = target.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == args.size }
        if (m == null) false else { m.invoke(target, *args); true }
    } catch (e: Exception) { false }

    private fun varsArray(pairs: List<Pair<String, String>>): Any? = try {
        val cls = Class.forName("com.swordfish.libretrodroid.Variable")
        val ctor = cls.getConstructor(String::class.java, String::class.java)
        val arr = java.lang.reflect.Array.newInstance(cls, pairs.size)
        pairs.forEachIndexed { i, kv -> java.lang.reflect.Array.set(arr, i, ctor.newInstance(kv.first, kv.second)) }
        arr
    } catch (e: Exception) { null }

    private fun pushVar(key: String, value: String) {
        val r = retro ?: return
        val arr = varsArray(listOf(key to value)) ?: return
        try { r.javaClass.methods.firstOrNull { it.name == "updateVariables" }?.invoke(r, arr) } catch (_: Exception) {}
    }

    private fun motionConst(name: String, fallback: Int): Int =
        try { GLRetroView::class.java.getField(name).getInt(null) } catch (e: Exception) { fallback }

    private val srcLeft by lazy { motionConst("MOTION_SOURCE_ANALOG_LEFT", 1) }
    private val srcRight by lazy { motionConst("MOTION_SOURCE_ANALOG_RIGHT", 2) }
    private var motionMethod: java.lang.reflect.Method? = null

    private fun motion(src: Int, x: Float, y: Float) {
        val r = retro ?: return
        try {
            val m = motionMethod ?: r.javaClass.methods.firstOrNull { it.name == "sendMotionEvent" }?.also { motionMethod = it } ?: return
            if (m.parameterTypes.size >= 4) m.invoke(r, src, x, y, 0) else m.invoke(r, src, x, y)
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ input mapping
    private fun keyFor(id: String): Int {
        val variant = prefs.getInt("mapvariant", 0)
        return when (id) {
            "A" -> if (variant == 1) KeyEvent.KEYCODE_BUTTON_B else KeyEvent.KEYCODE_BUTTON_A
            "B" -> when (variant) { 1 -> KeyEvent.KEYCODE_BUTTON_Y; 2 -> KeyEvent.KEYCODE_BUTTON_B; else -> KeyEvent.KEYCODE_BUTTON_X }
            "Z" -> KeyEvent.KEYCODE_BUTTON_L2
            "L" -> KeyEvent.KEYCODE_BUTTON_L1
            "R" -> KeyEvent.KEYCODE_BUTTON_R1
            "START" -> KeyEvent.KEYCODE_BUTTON_START
            "UP" -> KeyEvent.KEYCODE_DPAD_UP
            "DOWN" -> KeyEvent.KEYCODE_DPAD_DOWN
            "LEFT" -> KeyEvent.KEYCODE_DPAD_LEFT
            else -> KeyEvent.KEYCODE_DPAD_RIGHT
        }
    }

    override fun onKey(id: String, down: Boolean) {
        retro?.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, keyFor(id))
    }
    override fun onStick(x: Float, y: Float) = motion(srcLeft, x, y)
    override fun onC(x: Float, y: Float) = motion(srcRight, x, y)

    // ------------------------------------------------------------------- lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ge64", MODE_PRIVATE)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#020305")) }

        pad = N64Pad(this).apply {
            haptics = prefs.getBoolean("haptics", true)
            alpha = prefs.getInt("alpha", 100) / 100f
            gameRatio = currentRatio()
            listener = this@MainActivity
        }
        root.addView(pad, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        splash = TextView(this).apply {
            text = "◆  NINTENDO 64  ◆\n\nTap to choose your game file\n(.z64 / .n64 / .v64)"
            gravity = Gravity.CENTER
            setTextColor(gold)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            letterSpacing = 0.12f
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
            setOnClickListener { picker.launch(arrayOf("*/*")) }
        }
        root.addView(splash, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.CENTER))

        val menu = TextView(this).apply {
            text = "☰"
            setTextColor(gold)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            alpha = 0.6f
            setOnClickListener { showMenu() }
        }
        root.addView(menu, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(10) })

        setContentView(root)
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> layoutGame(r - l, b - t) }

        prefs.getString("rom", null)?.let { startGame(Uri.parse(it)) }
    }

    private fun optValue(o: Opt): String = prefs.getString("opt_${o.key}", o.values[o.def]) ?: o.values[o.def]
    private fun optIdx(o: Opt) = o.values.indexOf(optValue(o)).coerceAtLeast(0)

    private fun currentRatio(): Float {
        val aspect = OPTS.first { it.key == ASPECT_KEY }.let { optValue(it) }
        return if (aspect == "4:3") 0.75f else 0.5625f
    }

    private fun layoutGame(w: Int, h: Int) {
        val v = retro ?: return
        val lp = v.layoutParams as FrameLayout.LayoutParams
        val wantH = if (h > w) (w * pad.gameRatio).toInt() else MATCH_PARENT
        if (lp.height != wantH || lp.width != MATCH_PARENT) {
            lp.width = MATCH_PARENT; lp.height = wantH; lp.gravity = Gravity.TOP
            v.post { v.layoutParams = lp }
        }
    }

    private fun startGame(uri: Uri) {
        try {
            val name = uri.lastPathSegment ?: "game.z64"
            val ext = name.substringAfterLast('.', "z64").lowercase().let { if (it == "z64" || it == "n64" || it == "v64") it else "z64" }
            val rom = File(cacheDir, "game.$ext")
            cacheDir.listFiles()?.filter { it.name.startsWith("game.") && it != rom }?.forEach { it.delete() }
            Toast.makeText(this, "Loading game…", Toast.LENGTH_SHORT).show()
            contentResolver.openInputStream(uri)!!.use { input -> rom.outputStream().use { out -> input.copyTo(out) } }

            romKey = uri.toString().hashCode().toString()
            val sram = File(filesDir, "sram_$romKey.bin")
            val data = GLRetroViewData(this).apply {
                coreFilePath = "libmupen64plus_next_gles3_libretro_android.so"
                gameFilePath = rom.absolutePath
                systemDirectory = filesDir.absolutePath
                savesDirectory = File(filesDir, "saves").apply { mkdirs() }.absolutePath
                if (sram.exists()) saveRAMState = sram.readBytes()
                preferLowLatencyAudio = true
            }
            val arr = varsArray(OPTS.map { it.key to optValue(it) })
            if (arr != null) {
                try { data.javaClass.methods.firstOrNull { it.name == "setVariables" }?.invoke(data, arr) } catch (_: Exception) {}
            }
            val v = GLRetroView(this, data)
            lifecycle.addObserver(v)
            retro = v
            root.addView(v, 0, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT, Gravity.TOP))
            splash.visibility = View.GONE
            layoutGame(root.width, root.height)
            handler.postDelayed(autosave, 30_000)
            handler.postDelayed({ applyAllCheats() }, 2500)
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open game: ${e.message}", Toast.LENGTH_LONG).show()
            prefs.edit().remove("rom").apply()
            splash.visibility = View.VISIBLE
        }
    }

    private fun saveSram() {
        val r = retro ?: return
        try { File(filesDir, "sram_$romKey.bin").writeBytes(r.serializeSRAM()) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------------ menus
    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(arrayOf("💾 Save state", "📂 Load state", "⚙ Settings", "🎯 Cheats", "🔄 Restart game", "📁 Change game file")) { _, i ->
                when (i) {
                    0 -> retro?.let {
                        File(filesDir, "state_$romKey.bin").writeBytes(it.serializeState())
                        Toast.makeText(this, "State saved", Toast.LENGTH_SHORT).show()
                    }
                    1 -> retro?.let {
                        val f = File(filesDir, "state_$romKey.bin")
                        if (f.exists()) { it.unserializeState(f.readBytes()); Toast.makeText(this, "State loaded", Toast.LENGTH_SHORT).show() }
                        else Toast.makeText(this, "No saved state yet", Toast.LENGTH_SHORT).show()
                    }
                    2 -> showSettings()
                    3 -> showCheats()
                    4 -> { saveSram(); recreate() }
                    5 -> picker.launch(arrayOf("*/*"))
                }
            }.show()
    }

    private fun showSettings() {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        for (o in OPTS) {
            labels.add("${o.label}: ${o.names[optIdx(o)]}")
            acts.add { chooseOpt(o) }
        }
        labels.add("Quality preset…")
        acts.add { choosePreset() }
        labels.add("Pad opacity: ${(pad.alpha * 100).toInt()}%")
        acts.add {
            val next = when (prefs.getInt("alpha", 100)) { 100 -> 80; 80 -> 60; 60 -> 40; else -> 100 }
            prefs.edit().putInt("alpha", next).apply(); pad.alpha = next / 100f; showSettings()
        }
        labels.add("Haptics: ${if (pad.haptics) "on" else "off"}")
        acts.add {
            pad.haptics = !pad.haptics
            prefs.edit().putBoolean("haptics", pad.haptics).apply(); showSettings()
        }
        labels.add("Button mapping fix (now: ${prefs.getInt("mapvariant", 0) + 1} of 3)")
        acts.add {
            val next = (prefs.getInt("mapvariant", 0) + 1) % 3
            prefs.edit().putInt("mapvariant", next).apply()
            Toast.makeText(this, "Mapping ${next + 1}/3. If A/B/Z don't act right in game, cycle again.", Toast.LENGTH_LONG).show()
            showSettings()
        }
        labels.add("Fast-forward: ${fastForward}x")
        acts.add {
            fastForward = when (fastForward) { 1 -> 2; 2 -> 4; else -> 1 }
            val ok = retro?.let { callMethod(it, "setFrameSpeed", fastForward) } ?: false
            if (!ok) Toast.makeText(this, "Fast-forward not supported by this LibretroDroid version", Toast.LENGTH_LONG).show()
            showSettings()
        }
        labels.add("Sound: ${if (muted) "muted" else "on"}")
        acts.add {
            muted = !muted
            val ok = retro?.let { callMethod(it, "setAudioEnabled", !muted) } ?: false
            if (!ok) Toast.makeText(this, "Mute not supported by this LibretroDroid version", Toast.LENGTH_LONG).show()
            showSettings()
        }
        labels.add("About TAA / VSync")
        acts.add {
            Toast.makeText(this, "TAA doesn't exist in this emulator core; use MSAA/FXAA. VSync is handled by Android's display sync.", Toast.LENGTH_LONG).show()
        }

        AlertDialog.Builder(this).setTitle("Settings")
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .setNegativeButton("Close", null).show()
    }

    private fun setOpt(o: Opt, value: String) {
        prefs.edit().putString("opt_${o.key}", value).apply()
        pushVar(o.key, value)
        if (o.key == ASPECT_KEY) { pad.gameRatio = currentRatio(); layoutGame(root.width, root.height) }
    }

    private fun chooseOpt(o: Opt) {
        AlertDialog.Builder(this).setTitle(o.label)
            .setSingleChoiceItems(o.names.toTypedArray(), optIdx(o)) { d, which ->
                setOpt(o, o.values[which])
                Toast.makeText(this, "Saved. Menu → Restart game applies everything fully.", Toast.LENGTH_SHORT).show()
                d.dismiss(); showSettings()
            }.show()
    }

    private fun choosePreset() {
        val names = arrayOf("Performance (640x480, no AA)", "Balanced (960x720, FXAA)", "Quality (1280x960, 4x MSAA + FXAA)")
        AlertDialog.Builder(this).setTitle("Quality preset")
            .setItems(names) { _, which ->
                val byKey = OPTS.associateBy { it.key }
                val res = byKey.getValue("mupen64plus-43screensize"); val msaa = byKey.getValue("mupen64plus-MultiSampling"); val fx = byKey.getValue("mupen64plus-FXAA")
                when (which) {
                    0 -> { setOpt(res, "640x480"); setOpt(msaa, "0"); setOpt(fx, "0") }
                    1 -> { setOpt(res, "960x720"); setOpt(msaa, "0"); setOpt(fx, "1") }
                    else -> { setOpt(res, "1280x960"); setOpt(msaa, "4"); setOpt(fx, "1") }
                }
                Toast.makeText(this, "Preset saved. Menu → Restart game to apply.", Toast.LENGTH_LONG).show()
                showSettings()
            }.show()
    }

    // ------------------------------------------------------------------------ cheats
    private fun loadCheats(): MutableList<Cheat> {
        val out = ArrayList<Cheat>()
        try {
            val arr = JSONArray(prefs.getString("cheats_$romKey", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Cheat(o.getString("n"), o.getString("c"), o.getBoolean("e")))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun saveCheats(list: List<Cheat>) {
        val arr = JSONArray()
        for (c in list) arr.put(JSONObject().put("n", c.name).put("c", c.code).put("e", c.on))
        prefs.edit().putString("cheats_$romKey", arr.toString()).apply()
    }

    private fun applyCheat(index: Int, c: Cheat): Boolean {
        val r = retro ?: return false
        val code = c.code.trim().lines().filter { it.isNotBlank() }.joinToString("+") { it.trim() }
        return callMethod(r, "setCheat", index, c.on, code)
    }

    private fun applyAllCheats() {
        loadCheats().forEachIndexed { i, c -> if (c.on) applyCheat(i, c) }
    }

    private fun showCheats() {
        val list = loadCheats()
        val names = list.map { it.name }.toTypedArray()
        val checked = BooleanArray(list.size) { list[it].on }
        AlertDialog.Builder(this).setTitle("Cheats (GameShark)")
            .setMultiChoiceItems(names, checked) { _, i, on ->
                list[i].on = on
                saveCheats(list)
                if (!applyCheat(i, list[i])) Toast.makeText(this, "Cheats not supported by this LibretroDroid version", Toast.LENGTH_LONG).show()
            }
            .setPositiveButton("Add") { _, _ -> addCheat() }
            .setNeutralButton("Delete") { _, _ -> deleteCheat() }
            .setNegativeButton("Close", null).show()
    }

    private fun addCheat() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Name (e.g. Infinite ammo)" }
        val code = EditText(this).apply {
            hint = "GameShark code, one line per entry"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            minLines = 3
        }
        box.addView(name); box.addView(code)
        AlertDialog.Builder(this).setTitle("Add cheat").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim(); val c = code.text.toString().trim()
                if (n.isNotEmpty() && c.isNotEmpty()) {
                    val list = loadCheats(); list.add(Cheat(n, c, false)); saveCheats(list)
                }
                showCheats()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun deleteCheat() {
        val list = loadCheats()
        if (list.isEmpty()) { Toast.makeText(this, "No cheats to delete", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Delete which cheat?")
            .setItems(list.map { it.name }.toTypedArray()) { _, i ->
                val c = list[i]
                if (c.on) { c.on = false; applyCheat(i, c) }
                list.removeAt(i); saveCheats(list); showCheats()
            }.show()
    }

    override fun onResume() { super.onResume(); if (retro != null) { handler.removeCallbacks(autosave); handler.postDelayed(autosave, 30_000) } }
    override fun onPause() { saveSram(); handler.removeCallbacks(autosave); super.onPause() }
    override fun onStop() { saveSram(); super.onStop() }
}
