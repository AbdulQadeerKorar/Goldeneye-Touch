package com.qadeer.ge

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Stylized N64 pad, no letters. Gold linework on gunmetal, white-gold glow when pressed.
 * Analog stick (left), four C pods (right stick), A=key, B=reload arc, Z=crosshair, R=scope, L=shield,
 * small compass D-pad, hex Start.
 */
class N64Pad(ctx: Context) : View(ctx) {

    interface Listener {
        fun onKey(id: String, down: Boolean)
        fun onStick(x: Float, y: Float)
        fun onC(x: Float, y: Float)
    }

    var listener: Listener? = null
    var haptics = true
    var gameRatio = 0.75f
        set(v) { field = v; if (width > 0) { layoutControls(width, height); invalidate() } }

    private val rects = LinkedHashMap<String, RectF>()
    private val roundIds = setOf("A", "B", "CU", "CD", "CL", "CR")
    private val cIds = setOf("CU", "CD", "CL", "CR")
    private val pillIds = setOf("Z", "L", "R")
    private val stickC = PointF(); private var stickR = 1f
    private val dpadC = PointF(); private var dpadR = 1f
    private var gameH = 0f
    private val held = HashSet<String>()
    private var sx = 0f; private var sy = 0f; private var sOn = false
    private var lastCx = 0f; private var lastCy = 0f
    private var dust = FloatArray(0)

    private val gold = Color.parseColor("#D9B54A")
    private val hot = Color.parseColor("#FFF3C4")
    private val ink = Color.parseColor("#07090D")
    private val steel = Color.parseColor("#1A1D26")

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun glyphFor(id: String): String = when (id) {
        "A" -> "key"; "B" -> "reload"; "Z" -> "cross"; "R" -> "scope"; "L" -> "shield"
        "CU" -> "cup"; "CD" -> "cdown"; "CL" -> "cleft"; "CR" -> "cright"
        else -> "start"
    }

    private fun circle(id: String, cx: Float, cy: Float, r: Float) { rects[id] = RectF(cx - r, cy - r, cx + r, cy + r) }
    private fun box(id: String, l: Float, t: Float, r: Float, b: Float) { rects[id] = RectF(l, t, r, b) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layoutControls(w, h) }

    private fun layoutControls(w: Int, h: Int) {
        rects.clear()
        val W = w.toFloat(); val H = h.toFloat()
        if (H > W) {
            gameH = W * gameRatio
            val ch = H - gameH; val top = gameH
            box("L", W * 0.04f, top + ch * 0.02f, W * 0.24f, top + ch * 0.095f)
            box("Z", W * 0.30f, top + ch * 0.02f, W * 0.70f, top + ch * 0.105f)
            box("R", W * 0.76f, top + ch * 0.02f, W * 0.96f, top + ch * 0.095f)
            stickR = min(W * 0.18f, ch * 0.20f); stickC.set(W * 0.23f, top + ch * 0.50f)
            dpadR = min(W * 0.09f, ch * 0.08f); dpadC.set(W * 0.50f, top + ch * 0.60f)
            val pr = W * 0.055f; val d = W * 0.115f
            val ccx = W * 0.79f; val ccy = top + ch * 0.34f
            circle("CU", ccx, ccy - d, pr); circle("CD", ccx, ccy + d, pr)
            circle("CL", ccx - d, ccy, pr); circle("CR", ccx + d, ccy, pr)
            circle("A", W * 0.88f, top + ch * 0.68f, W * 0.085f)
            circle("B", W * 0.70f, top + ch * 0.74f, W * 0.07f)
            val y = H - ch * 0.10f
            box("START", W * 0.40f, y, W * 0.60f, y + ch * 0.06f)
            val rnd = Random(5)
            dust = FloatArray(32 * 3)
            for (i in 0 until 32) {
                dust[i * 3] = rnd.nextFloat() * W
                dust[i * 3 + 1] = gameH + 14f + rnd.nextFloat() * (H - gameH - 14f)
                dust[i * 3 + 2] = 0.8f + rnd.nextFloat() * 1.8f
            }
        } else {
            gameH = 0f; dust = FloatArray(0)
            box("L", W * 0.02f, H * 0.05f, W * 0.15f, H * 0.15f)
            box("Z", W * 0.73f, H * 0.05f, W * 0.85f, H * 0.16f)
            box("R", W * 0.87f, H * 0.05f, W * 0.98f, H * 0.15f)
            stickR = H * 0.20f; stickC.set(W * 0.13f, H * 0.64f)
            dpadR = H * 0.09f; dpadC.set(W * 0.30f, H * 0.82f)
            val pr = H * 0.07f; val d = H * 0.14f
            val ccx = W * 0.75f; val ccy = H * 0.46f
            circle("CU", ccx, ccy - d, pr); circle("CD", ccx, ccy + d, pr)
            circle("CL", ccx - d, ccy, pr); circle("CR", ccx + d, ccy, pr)
            circle("A", W * 0.92f, H * 0.66f, H * 0.10f)
            circle("B", W * 0.82f, H * 0.84f, H * 0.085f)
            box("START", W * 0.45f, H * 0.90f, W * 0.55f, H * 0.97f)
        }
    }

    private fun col(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun diamond(c: Canvas, x: Float, y: Float, s: Float, fill: Boolean, color: Int, width: Float = 1.5f) {
        val path = Path().apply { moveTo(x, y - s); lineTo(x + s, y); lineTo(x, y + s); lineTo(x - s, y); close() }
        p.shader = null; p.color = color
        p.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE; p.strokeWidth = width
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val a = if (gameH > 0f) 255 else 175
        if (gameH > 0f) drawBackdrop(c, width.toFloat(), height.toFloat())
        drawStick(c, a)
        drawDpad(c, a)
        for ((id, r) in rects) {
            val on = id in held
            when (id) {
                in roundIds -> drawRound(c, id, r, a, on)
                in pillIds -> drawPill(c, id, r, a, on)
                else -> drawHex(c, id, r, a, on)
            }
        }
    }

    private fun drawBackdrop(c: Canvas, W: Float, H: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, gameH, 0f, H, Color.parseColor("#0E1118"), Color.parseColor("#020305"), Shader.TileMode.CLAMP)
        c.drawRect(0f, gameH, W, H, p); p.shader = null
        var i = 0
        while (i < dust.size) {
            p.color = col(gold, (26 + dust[i + 2] * 26).toInt()); p.style = Paint.Style.FILL
            c.drawCircle(dust[i], dust[i + 1], dust[i + 2], p); i += 3
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f
        p.shader = LinearGradient(0f, 0f, W, 0f,
            intArrayOf(col(gold, 0), col(gold, 220), col(gold, 0)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawLine(0f, gameH, W, gameH, p); p.shader = null
        // crosshair ornament on the divider
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = col(gold, 240)
        c.drawCircle(W / 2, gameH, 10f, p)
        c.drawLine(W / 2 - 18f, gameH, W / 2 - 6f, gameH, p); c.drawLine(W / 2 + 6f, gameH, W / 2 + 18f, gameH, p)
        diamond(c, W / 2 - 40f, gameH, 3.5f, true, col(gold, 170))
        diamond(c, W / 2 + 40f, gameH, 3.5f, true, col(gold, 170))
    }

    // ---------------------------------------------------------------- glyphs
    private fun glyph(c: Canvas, kind: String, cx: Float, cy: Float, s: Float, color: Int) {
        c.save(); c.translate(cx, cy); c.scale(s, s)
        p.shader = null; p.color = color
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            "key" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.09f
                c.drawCircle(-0.26f, 0f, 0.2f, p)
                c.drawLine(-0.06f, 0f, 0.46f, 0f, p)
                c.drawLine(0.22f, 0f, 0.22f, 0.2f, p)
                c.drawLine(0.38f, 0f, 0.38f, 0.18f, p)
            }
            "reload" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.09f
                c.drawArc(RectF(-0.36f, -0.36f, 0.36f, 0.36f), -60f, 300f, false, p)
                p.style = Paint.Style.FILL
                c.drawPath(Path().apply {
                    moveTo(-0.041f, -0.392f); lineTo(-0.23f, -0.399f); lineTo(-0.13f, -0.225f); close()
                }, p)
            }
            "cross" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.07f
                c.drawCircle(0f, 0f, 0.28f, p)
                c.drawLine(0f, -0.52f, 0f, -0.16f, p); c.drawLine(0f, 0.16f, 0f, 0.52f, p)
                c.drawLine(-0.52f, 0f, -0.16f, 0f, p); c.drawLine(0.16f, 0f, 0.52f, 0f, p)
                p.style = Paint.Style.FILL; c.drawCircle(0f, 0f, 0.05f, p)
            }
            "scope" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.07f
                c.drawCircle(0f, 0f, 0.44f, p)
                p.strokeWidth = 0.04f
                c.drawLine(0f, -0.44f, 0f, 0.44f, p); c.drawLine(-0.44f, 0f, 0.44f, 0f, p)
                p.style = Paint.Style.FILL; c.drawCircle(0f, 0f, 0.07f, p)
            }
            "shield" -> {
                val sh = Path().apply {
                    moveTo(-0.34f, -0.4f); lineTo(0.34f, -0.4f); lineTo(0.34f, 0.05f)
                    quadTo(0.34f, 0.36f, 0f, 0.52f); quadTo(-0.34f, 0.36f, -0.34f, 0.05f); close()
                }
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.08f; c.drawPath(sh, p)
                p.style = Paint.Style.FILL
                c.drawPath(Path().apply { moveTo(0f, -0.12f); lineTo(0.1f, 0.04f); lineTo(0f, 0.2f); lineTo(-0.1f, 0.04f); close() }, p)
            }
            "cup" -> { p.style = Paint.Style.STROKE; p.strokeWidth = 0.14f
                c.drawPath(Path().apply { moveTo(-0.4f, 0.2f); lineTo(0f, -0.22f); lineTo(0.4f, 0.2f) }, p) }
            "cdown" -> { p.style = Paint.Style.STROKE; p.strokeWidth = 0.14f
                c.drawPath(Path().apply { moveTo(-0.4f, -0.2f); lineTo(0f, 0.22f); lineTo(0.4f, -0.2f) }, p) }
            "cleft" -> { p.style = Paint.Style.STROKE; p.strokeWidth = 0.14f
                c.drawPath(Path().apply { moveTo(0.2f, -0.4f); lineTo(-0.22f, 0f); lineTo(0.2f, 0.4f) }, p) }
            "cright" -> { p.style = Paint.Style.STROKE; p.strokeWidth = 0.14f
                c.drawPath(Path().apply { moveTo(-0.2f, -0.4f); lineTo(0.22f, 0f); lineTo(-0.2f, 0.4f) }, p) }
            else -> { // start pointer
                p.style = Paint.Style.FILL
                c.drawPath(Path().apply { moveTo(-0.22f, -0.38f); lineTo(0.38f, 0f); lineTo(-0.22f, 0.38f); close() }, p)
            }
        }
        p.strokeCap = Paint.Cap.BUTT; p.strokeJoin = Paint.Join.MITER
        c.restore()
    }

    // --------------------------------------------------------------- controls
    private fun drawRound(c: Canvas, id: String, r: RectF, a: Int, on: Boolean) {
        val cx = r.centerX(); val cy = r.centerY(); val rad = r.width() / 2f
        val acc = if (on) hot else gold
        if (on) {
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx, cy, rad * 1.4f, col(hot, 100 * a / 255), col(hot, 0), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, rad * 1.4f, p)
        }
        p.style = Paint.Style.FILL
        p.shader = if (on)
            RadialGradient(cx, cy, rad, col(hot, 95 * a / 255), col(gold, 35 * a / 255), Shader.TileMode.CLAMP)
        else
            RadialGradient(cx, cy, rad, col(ink, 205 * a / 255), col(steel, 215 * a / 255), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, rad, p); p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.6f; p.color = col(acc, 235 * a / 255); c.drawCircle(cx, cy, rad, p)
        p.strokeWidth = 1.2f; p.color = col(acc, 110 * a / 255); c.drawCircle(cx, cy, rad * 0.82f, p)
        val s = rad * 0.075f
        for ((dx, dy) in listOf(0 to -1, 0 to 1, -1 to 0, 1 to 0))
            diamond(c, cx + dx * rad, cy + dy * rad, s, true, col(acc, 235 * a / 255))
        glyph(c, glyphFor(id), cx, cy, rad * 0.72f, col(acc, 245 * a / 255))
    }

    private fun drawPill(c: Canvas, id: String, r: RectF, a: Int, on: Boolean) {
        val acc = if (on) hot else gold
        val rad = r.height() / 2f
        p.style = Paint.Style.FILL; p.shader = null
        p.color = if (on) col(hot, 85 * a / 255) else col(ink, 205 * a / 255)
        c.drawRoundRect(r, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f; p.color = col(acc, 235 * a / 255)
        c.drawRoundRect(r, rad, rad, p)
        p.strokeWidth = 1.1f; p.color = col(acc, 100 * a / 255)
        c.drawRoundRect(RectF(r.left + 6, r.top + 6, r.right - 6, r.bottom - 6), rad, rad, p)
        diamond(c, r.left + rad * 0.55f, r.centerY(), rad * 0.2f, true, col(acc, 220 * a / 255))
        diamond(c, r.right - rad * 0.55f, r.centerY(), rad * 0.2f, true, col(acc, 220 * a / 255))
        glyph(c, glyphFor(id), r.centerX(), r.centerY(), r.height() * 0.36f, col(acc, 245 * a / 255))
    }

    private fun drawHex(c: Canvas, id: String, r: RectF, a: Int, on: Boolean) {
        val acc = if (on) hot else gold
        val h = r.height(); val cy = r.centerY()
        val path = Path().apply {
            moveTo(r.left, cy); lineTo(r.left + h / 2, r.top); lineTo(r.right - h / 2, r.top)
            lineTo(r.right, cy); lineTo(r.right - h / 2, r.bottom); lineTo(r.left + h / 2, r.bottom); close()
        }
        p.style = Paint.Style.FILL; p.shader = null
        p.color = if (on) col(hot, 85 * a / 255) else col(ink, 205 * a / 255)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = col(acc, 230 * a / 255)
        c.drawPath(path, p)
        glyph(c, glyphFor(id), r.centerX(), cy, h * 0.3f, col(acc, 240 * a / 255))
    }

    private fun drawStick(c: Canvas, a: Int) {
        val cx = stickC.x; val cy = stickC.y; val R = stickR
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, R * 1.25f, col(gold, 26 * a / 255), col(gold, 0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * 1.25f, p)
        p.shader = RadialGradient(cx, cy, R, col(ink, 160 * a / 255), col(steel, 190 * a / 255), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R, p); p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.6f; p.color = col(gold, 235 * a / 255); c.drawCircle(cx, cy, R, p)
        p.strokeWidth = 1.2f; p.color = col(gold, 100 * a / 255); c.drawCircle(cx, cy, R * 0.86f, p)
        p.strokeWidth = 1.8f; p.color = col(gold, 190 * a / 255)
        for (i in 0 until 8) {
            val t = Math.toRadians(i * 45.0)
            c.drawLine(cx + (R * 0.86f * cos(t)).toFloat(), cy + (R * 0.86f * sin(t)).toFloat(),
                cx + (R * cos(t)).toFloat(), cy + (R * sin(t)).toFloat(), p)
        }
        for ((dx, dy) in listOf(0 to -1, 0 to 1, -1 to 0, 1 to 0))
            diamond(c, cx + dx * R, cy + dy * R, R * 0.05f, true, col(gold, 240 * a / 255))
        // knob
        val kr = R * 0.42f
        val kx = cx + sx * R * 0.5f; val ky = cy + sy * R * 0.5f
        val acc = if (sOn) hot else gold
        if (sOn) {
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(kx, ky, kr * 1.5f, col(hot, 90 * a / 255), col(hot, 0), Shader.TileMode.CLAMP)
            c.drawCircle(kx, ky, kr * 1.5f, p)
        }
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(kx - kr * 0.25f, ky - kr * 0.25f, kr * 1.3f,
            col(acc, (if (sOn) 190 else 120) * a / 255), col(ink, 235 * a / 255), Shader.TileMode.CLAMP)
        c.drawCircle(kx, ky, kr, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f; p.color = col(acc, 240 * a / 255); c.drawCircle(kx, ky, kr, p)
        p.strokeWidth = 1.1f; p.color = col(acc, 120 * a / 255); c.drawCircle(kx, ky, kr * 0.6f, p)
        diamond(c, kx, ky, kr * 0.16f, true, col(acc, 245 * a / 255))
    }

    private fun drawDpad(c: Canvas, a: Int) {
        val cx = dpadC.x; val cy = dpadC.y; val r = dpadR
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f; p.color = col(gold, 70 * a / 255)
        c.drawCircle(cx, cy, r * 1.1f, p)
        val w = r * 0.26f
        val petal = Path().apply {
            moveTo(cx, cy - r)
            lineTo(cx + w, cy - r * 0.52f); lineTo(cx + w * 0.62f, cy - r * 0.25f)
            lineTo(cx - w * 0.62f, cy - r * 0.25f); lineTo(cx - w, cy - r * 0.52f); close()
        }
        val dirs = listOf("UP" to 0f, "RIGHT" to 90f, "DOWN" to 180f, "LEFT" to 270f)
        for ((id, deg) in dirs) {
            val on = id in held
            c.save(); c.rotate(deg, cx, cy)
            p.style = Paint.Style.FILL; p.shader = null
            p.color = if (on) col(hot, 190 * a / 255) else col(steel, 215 * a / 255)
            c.drawPath(petal, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = col(if (on) hot else gold, 235 * a / 255)
            c.drawPath(petal, p)
            c.restore()
        }
        p.style = Paint.Style.FILL; p.color = col(ink, 245 * a / 255); c.drawCircle(cx, cy, r * 0.2f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = col(gold, 235 * a / 255); c.drawCircle(cx, cy, r * 0.2f, p)
        diamond(c, cx, cy, r * 0.07f, true, col(gold, 240 * a / 255))
    }

    // ----------------------------------------------------------------- touch
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val now = HashSet<String>()
        var nsx = 0f; var nsy = 0f; var nOn = false
        val ending = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        if (!ending) {
            val slop = width * 0.008f
            for (i in 0 until e.pointerCount) {
                if (e.actionMasked == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                val x = e.getX(i); val y = e.getY(i)
                val sRatio = hypot(x - stickC.x, y - stickC.y) / stickR
                val dRatio = hypot(x - dpadC.x, y - dpadC.y) / dpadR
                if (!nOn && sRatio < 1.5f && sRatio <= dRatio) {
                    nOn = true
                    var vx = (x - stickC.x) / stickR; var vy = (y - stickC.y) / stickR
                    val len = hypot(vx, vy)
                    if (len > 1f) { vx /= len; vy /= len }
                    nsx = vx; nsy = vy
                } else if (dRatio < 1.5f && dRatio > 0.15f) {
                    val dx = x - dpadC.x; val dy = y - dpadC.y
                    val t = hypot(dx, dy) * 0.38f
                    if (dx < -t) now += "LEFT"; if (dx > t) now += "RIGHT"
                    if (dy < -t) now += "UP"; if (dy > t) now += "DOWN"
                }
                for ((id, r) in rects) {
                    if (x >= r.left - slop && x <= r.right + slop && y >= r.top - slop && y <= r.bottom + slop) now += id
                }
            }
        }
        for (id in now) if (id !in held) {
            if (id !in cIds) listener?.onKey(id, true)
            if (haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
        for (id in held) if (id !in now && id !in cIds) listener?.onKey(id, false)
        held.clear(); held.addAll(now)

        if (nOn != sOn || nsx != sx || nsy != sy) {
            sOn = nOn; sx = nsx; sy = nsy
            listener?.onStick(sx, sy)
        }
        val ccx = (if ("CR" in now) 1f else 0f) - (if ("CL" in now) 1f else 0f)
        val ccy = (if ("CD" in now) 1f else 0f) - (if ("CU" in now) 1f else 0f)
        if (ccx != lastCx || ccy != lastCy) { lastCx = ccx; lastCy = ccy; listener?.onC(ccx, ccy) }
        invalidate()
        return true
    }
}
